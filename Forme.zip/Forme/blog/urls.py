from . import views
from django.urls import path

urlpatterns = [
    path('', views.register, name="register"),
    path('resultat', views.resultat, name="resultat"),
    
]
