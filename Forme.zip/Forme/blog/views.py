from django.shortcuts import render, redirect
from .models import Student
from django.contrib.auth.models import User
from django.contrib import messages
from .forms import StudentForm

def form(request):
	return render(request, 'form.html')

def register(request):
	if request.method == 'POST':
		form = StudentForm(request.POST)
		if form.is_valid():
			name = form.cleaned_data['name']
			surname = form.cleaned_data['surname']
			username = form.cleaned_data['username']
			reg_number = form.cleaned_data['reg_number']
			date_birth = form.cleaned_data['date_birth']
			location = form.cleaned_data['location']
			user = User.objects.create_user(username=username, password=reg_number)
			if user is not None:
				return redirect("resultat")
			else:
				messages.error(request, 'Création de compte échouée')
				return render(request, 'register.html', {'form': form})
		else:
			return render(request, 'register.html', {'form':form})
		return redirect("resultat")
	form = StudentForm()
	return render(request, 'register.html', {'form':form})


def resultat(request, reg_number):
	student = Student.objects.get(id=reg_number)
	list_student = Student.objects.all()
	return render(request, 'resultat.html', {"student":student})


