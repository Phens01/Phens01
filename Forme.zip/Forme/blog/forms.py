from django import forms 
from .models import Student

class StudentForm(forms.ModelForm):
	class Meta:
		model = Student
		fields = ['name', 'surname', 'username', 'reg_number', 'date_birth', 'location']
		labels = {'name':'Nom', 'surname': 'Prénom', 'username':'Pseudo', 'reg_number':'Matricule', 'date_birth':'Date de Naissance', 'location':'Lieu'}
		widgets = {
			'name':forms.TextInput(attrs={'class':'form-control'}),
			'surname':forms.TextInput(attrs={'class':'form-control'}),
			'username':forms.TextInput(attrs={'class':'form-control'}),
			'reg_number':forms.TextInput(attrs={'class':'form-control'}),
			'location':forms.TextInput(attrs={'class': 'form-control'}),
			'date_birth':forms.DateInput(attrs={'class':'form-control'}),
			
		}