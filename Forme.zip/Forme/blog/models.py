from django.db import models
from django.contrib.auth.models import User


class Student(models.Model):
	slug = models.SlugField()
	name = models.TextField()
	surname = models.TextField()
	username = models.TextField()
	reg_number = models.TextField(max_length=10)
	date_birth = models.DateField(auto_now = False)
	location = models.TextField()
	date_added = models.DateTimeField(auto_now = True)

	def __str__(self):
		return self.username

	class Meta:
		ordering = ['-date_added']
